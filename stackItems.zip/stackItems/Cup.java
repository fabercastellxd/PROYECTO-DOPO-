
/**
 * Write a description of class Cup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cup{
    private int height;
    private int width;
    private boolean isVisible;
    private String color;
    private int number;
    private Rectangle cup;
    
    
    public Cup(int i){
        number = i;
        height = 2*i - 1;
        width = 1;
        isVisible = false;
        color = assignColor(i);
        
        cup = new Rectangle();
        cup.changeColor("yellow");
        cup.changeSize(height, width * 40);
    }
    
    public void makeVisible(){
        isVisible = true;
        cup.makeVisible();
    }
    
    public void makeInvisible(){
        isVisible = false;
        cup.makeInvisible();
    }
    
    public Rectangle getCup(){
        return cup;
    }
    
    public int getHeight(){
        return height;
    }
    
    public String getColor(){
        return color;
    }
    
    public int getNumber(){
        return number;
    }
    
    public boolean getVisible(){
        return isVisible;
    }
    
    private String assignColor(int i){
        String[] colors = {"red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink"};
        return colors[(i - 1) % colors.length];
    }
}