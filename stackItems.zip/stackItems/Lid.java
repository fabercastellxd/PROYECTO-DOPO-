
/**
 * Write a description of class Cup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lid{
    private int height;
    private int width;
    private boolean isVisible;
    private String color;
    private int number;
    private Rectangle lid;
    
    
    public Lid(int i){
        number = i;
        height = i;
        width = 1;
        isVisible = false;
        color = assignColor(i);
        
        lid = new Rectangle();
        lid.changeColor(color);
        lid.changeSize(height * 10, width * 40);
    }
    
    public void makeVisible(){
        isVisible = true;
        lid.makeVisible();
    }
    
    public void makeInvisible(){
        isVisible = false;
        lid.makeInvisible();
    }
    
    public Rectangle getCup(){
        return lid;
    }
    
    public int getHeight(){
        return height;
    }
    
    public String getColor(){
        return color;
    }
    
    public int getNumber(){
        return number;
    }
    
    public boolean getVisible(){
        return isVisible;
    }
    
    private String assignColor(int i){
        String[] colors = {"red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink"};
        return colors[(i - 1) % colors.length];
    }
}