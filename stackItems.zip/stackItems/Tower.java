import java.util.ArrayList;
import java.util.Collections;
/**
 * Simulador de la torre de tazas.
 * 
 * @author (Juan Jose Perez y Maria Angelica Perez) 
 * @version (15/02/2025)
 */
public class Tower{
    private int width;
    private int maxHeight;
    private boolean isVisible;
    private boolean lastOperationOk;
    
    private Rectangle linea;
    private ArrayList<Rectangle> marcadores;
    private ArrayList<Cup> cups;
    private ArrayList<Lid> lids;
    
    public Tower(){
        width = 10;
        maxHeight = 10;
        isVisible = false;
        lastOperationOk = true;
        marcadores = new ArrayList<Rectangle>();
        cups = new ArrayList<Cup>();
        
    }
    
    public void makeVisible(){
        isVisible = true;
        /**
         * Se crea un nuevo rectangulo que sera la "linea" que marcara 
         * las dimensiones de la torre
         */
        linea = new Rectangle();
        linea.changeColor("black");
        linea.changeSize(2, 280);
        linea.moveVertical(280);
        linea.moveHorizontal(-65);
        linea.makeVisible();
        
        for (int i = 0; i < cups.size(); i++) {
            cups.get(i).makeVisible();
        }
        
        repositionCups();
    }
    
    public void makeInvisible() {
        isVisible = false;
        
        if (linea != null) {
            linea.makeInvisible();
        }
        
        for (int i = 0; i < cups.size(); i++) {
            cups.get(i).makeInvisible();
        }
    }
    
    private boolean existCup(int i){
        for (int idx = 0; idx < cups.size(); idx++){
            if (cups.get(idx).getNumber() == i) {
                return true;
            }
        }
        return false;
        
    }
    public void pushCup(int i){
        if (existCup(i) || cups.size() >= maxHeight) {
            lastOperationOk = false;
            return;
        }
        
        Cup cup = new Cup(i);
        cups.add(cup);
        
        if(isVisible) {
            cup.makeVisible();
        }
        
        lastOperationOk = true;
    }
    
    private void repositionCups(){
        int y = 260;
        
        for (int idx = 0; idx < cups.size(); idx++){
            Cup cup = cups.get(idx);
            Rectangle r = cup.getCup();
            
            r.moveHorizontal(-65);
            r.moveVertical(y);
            
            y -= cup.getHeight();
        }
    }
    
    public void popCup() {
        if (cups.isEmpty()) {
            lastOperationOk = false;
            return;
        }
        
        Cup removedCup = cups.remove(cups.size() - 1);
        
        if (isVisible) {
            removedCup.makeInvisible();
        }
        
        repositionCups();
        lastOperationOk = true;
    }
    
    public void removeCup(int i) {
        Cup cupToRemove = null;
        
        for (Cup cup : cups) {
            if (cup.getNumber() == i){
                cupToRemove = cup;
                break;
            }
        }
        
        if (cupToRemove == null) {
            lastOperationOk = false;
            return;
        }
        
        cups.remove(cupToRemove);
        
        if (isVisible) {
            cupToRemove.makeInvisible();
        }
        
        repositionCups();
        lastOperationOk = true;
    }
    
    private Lid findLid(int number) {
        for (Lid lid : lids) {
            if(lid.getNumber() == number){
                return lid;
            }
        }
        return null;
    }
    
    private void repositionLids() {
        int y = 260;
        
        for (Lid lid : lids) {
            Rectangle r = lid.getCup();
            r.moveHorizontal(-65);
            r.moveVertical(y);
            y -= lid.getHeight();
        }
    }
    public void pushLid(int i) {
        if (findLid(i) != null || lids.size() >= maxHeight) {
            lastOperationOk = false;
            return;
        }
        
        Lid lid = new Lid(i);
        lids.add(lid);
        
        if (isVisible) {
            lid.makeVisible();
        }
        
        repositionLids();
        lastOperationOk = true;
        
    }
    
    public void popLid(){
        if (lids.isEmpty()) {
            lastOperationOk = false;
            return;
        }
        
        Lid removed = lids.remove(lids.size() - 1);
        
        if (isVisible) {
            removed.makeInvisible();
        }
        
        repositionLids();
        lastOperationOk = true;
    }
    
    public void removeLids(int i) {
        Lid lid = findLid(i);
        
        if (lid == null) {
            lastOperationOk = false;
            return;
        }
        
        lids.remove(lid);
        
        if (isVisible) {
            lid.makeInvisible();
        }
        
        repositionLids();
        lastOperationOk = true;
    }
}
    
    
