
/**
 * Representa lo que es una taza en el simulador
 * Como es un rectangulo, hereda algunos de sus metodos y atributos de Rectangle
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cup extends Rectangle{
    private int number;
    private String color;
    private int width;
    private int height;
    private boolean isVisible;
    private int thick;
    private int diameter;
    
    /**
     * Se crea una taza con identificador i y altura 2i -1
     */
    public Cup(int i){
        number = i;
        height = 2*i - 1;
        width = i * 40;
        thick = 1;
        diameter = i;
        isVisible = false;
        color = assignColor(i);
        
        changeColor(color);
        changeSize(height * 10, width);
    }
    
    /**
     * Hace visible la taza
     */
    public void makeVisible(){
        isVisible = true;
        super.makeVisible();
    }
    
    /**
     * Hace visible la taza
     */
    public void makeInvisible(){
        isVisible = false;
        super.makeInvisible();
    }
    
    /**
     * Retorna la taza
     */
    public Rectangle getCup(){
        return this;
    }
    
    /**
     * Retorna la altura de la taza
     */
    public int getHeight(){
       return height; 
    }
    
    /**
     * Retorna el ancho de la taza
     */
    public int getWidth(){
        return width;
    }
    
    /**
     * Retorna el diametro de la taza
     */
    public int getDiameter(){
        return diameter;
    }
    
    /**
     * Retorna el identificador i de la taza
     */
    public int getNumber(){
        return number;
    }
    
    /**
     * Retorna el color de la taza
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Retorna si la taza es visible o no
     */
    public boolean getVisible(){
        return isVisible;
    }
    
    /**
     * Retorna el tipo del objeto
     */
    public String getType(){
        return "cup";
    }
    
    /**
     * Metodo para asignarle un color a la taza dependiendo del ifentificador i
     */
    private String assignColor(int i){
        String[] colors = {"red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink"};
        return colors[(i - 1) % colors.length];
    }
}