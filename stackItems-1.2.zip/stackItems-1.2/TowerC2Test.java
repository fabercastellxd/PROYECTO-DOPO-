import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Write a description of class TowerC2Test here.
 * 
 * @author Juan Jose Perez Torres
 * @author Maria Angelica Perez Mesa
 * @version (a version number or a date)
 */
public class TowerC2Test
{
    private Tower tower;
    
    @Before
    public void setUp(){
        tower = new Tower();
    }
    
    //Pruebas para la torre Tower(int cup)
    
    @Test //Una torre inicializada con n tapas deberia tener n elementos en la pila
    public void testTowerWithCupsShouldHaveSameNumberOfItems(){
        Tower t = new Tower(6);
        assertEquals(6, t.stackItems().length);
    }
    
    @Test //una torre sin elementos deberia tener una pila vacia
    public void testTowerWithNothingItemsShouldBeEmpty(){
        Tower t = new Tower(0);
        assertEquals(0, t.stackItems().length);
    }
    
    //Pruebas para pushCup
    
    @Test //pushCup deberia aumentar el numero de elementos en la pila
    public void testPushCupShouldIncreaseStack(){
        tower.pushCup(2);
        assertEquals(1, tower.stackItems().length);
    }
    
    @Test //Multiples pushCup deberian agregar cups sin problema
    public void testMultipleCupsShouldBeAdd(){
        tower.pushCup(2);
        tower.pushCup(6);
        tower.pushCup(1);
        assertEquals(3, tower.stackItems().length);
    }
    
    //Pruebas para popCup
    
    @Test //popCup deberia reducir el numero de elementos en la pila
    public void testPopCupShouldDecreaseStack(){
        tower.pushCup(1);
        tower.popCup();
        assertEquals(0, tower.stackItems().length);
    }
    
    @Test //popCup no deberia funcionar si en la torre solo hay lids
    public void testShouldNotWorkIfThereAreOnlyLidsOnTheTower(){
        tower.pushLid(2);
        tower.popCup();
        assertFalse(tower.ok());
    }
    
    //Pruebas para removeCup
    
    @Test //removeCup tambien deberia disminuir el numero de elementos en la pila
    public void testRemoveCupShouldDecreaseStack(){
        tower.pushCup(3);
        tower.pushCup(6);
        tower.pushCup(2);
        tower.pushCup(1);
        tower.removeCup(2);
        tower.removeCup(3);
        assertEquals(2, tower.stackItems().length);
        
    }
    
    @Test //Si en la torre se encuentra la taza y tapa de numero i, removeCup(i) deberia 
          //dejar solo a la tapa sin algun problema
    public void testRemoveCupShouldNotAffectLids(){
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(1);
        tower.removeCup(1);
        assertEquals(2, tower.stackItems().length);
        
    }
    
    //Pruebas para pushLid
    
    @Test //pushLid deberia aumentar el numero de elementos que hay en la pila
    public void testPushLidSHouldIncreaseStack(){
        tower.pushLid(6);
        assertEquals(1, tower.stackItems().length);
    }
    
    @Test //Como la altura maxima de la torre es 10, si se le agregan 10 elementos y despues 
          //otro mas, no deberia poderse agregar debido a que la torre esta llena
    public void testPushLidShouldNotWorkIfTowerIsFull(){
        Tower t = new Tower(10);
        t.pushLid(2);
        assertFalse(t.ok());
    }
    
    //Pruebas para popLid
    
    @Test //popLid disminuye el numero de elementos en la pila
    public void testPopLidShouldDecreaseStack(){
        tower.pushLid(2);
        tower.popLid();
        assertEquals(0, tower.stackItems().length);
    }
    
    @Test //Si solo hay cups en la torre, popLid no funciona
    public void testPopLidShouldNotWorkIfThereAreOnlyCupsOnTheTower(){
        tower.pushCup(5);
        tower.popLid();
        assertFalse(tower.ok());
    }
    
    //pruebas para removeLid
    
    @Test
    public void testRemoveLidShouldDecreaseStack(){
        tower.pushLid(1);
        tower.pushLid(2);
        tower.pushLid(3);
        tower.removeLid(1);
        assertEquals(2, tower.stackItems().length);
    }
    
    //Pruebas para swap
    
    @Test //Swap deberia intercambiar la posicion de las tazas en la torre
    public void testSwapShoulChangeCupsPosition(){
        tower.pushCup(6);
        tower.pushCup(4);
        tower.swap(new String[]{"cup","6"}, new String[]{"cup", "4"});
        assertEquals("cup",tower.stackItems()[0][0]);
        assertEquals("4",tower.stackItems()[0][1]);
    }
    
    @Test //Swap deberia funcionar intercambiando tazas con tapas y viceversa y tapas con tapas
          //y tazas con tazas
    public void testSwapShouldWorkWithCupsAndLids(){
        tower.pushCup(3);
        tower.pushLid(1);
        tower.swap(new String[]{"cup","3"}, new String[]{"lid", "1"});
        assertTrue(tower.ok());
    }
    
    //Pruebas para cover
    
    @Test //Cover marca las tazas tapadas con un color diferente y despues se llama
          //a lidedCups para verificar que si retorne el numero de tazas con tapa presente
    public void testCoverShouldFinCupWithItsLid(){
        tower.pushCup(1);
        tower.pushLid(1);
        tower.pushCup(4);
        tower.pushLid(4);
        tower.cover();
        assertEquals(2, tower.lidedCups().length);
    }
    
    @Test //Si el numero de la tapa y la taza no coincide, pues cover no los marca y
          //lidedCups retorna 0
    public void testCpverShouldNotFindPairWhenNumbersDontMatch(){
        tower.pushCup(1);
        tower.pushLid(2);
        assertEquals(0, tower.lidedCups().length);
    }
    
    //pruebas para height
    @Test
    public void testHeightShouldReturnTotalHeightIncludeAllItems(){
        tower.pushCup(4);
        tower.pushCup(2);
        tower.pushLid(1);
        tower.pushLid(2);
        assertEquals(12, tower.height());
    }
    
    @Test
    public void testHeightShouldReturnCorrectHeightAfterPopOrRemove(){
        tower.pushCup(1);
        tower.pushCup(4);
        tower.pushLid(1);
        tower.popCup();
        tower.popCup();
        tower.pushLid(2);
        tower.pushCup(3);
        tower.removeLid(2);
        assertEquals(6, tower.height());
    }
    
    //Pruebas para swapToReduce
    
    @Test //Cambia la posicion de dos elementos para reducir la altura
    public void testSwapToReduceShouldReturnNullWhenHeightIsSimpleSum(){
        tower.pushCup(1);
        tower.pushCup(2);
        assertNull(tower.swapToReduce());
    }
    
    @Test //Retorna null si solo hay un elemento
    public void testSwapToReduceShouldReturnNullWithSingleItem(){
        tower.pushCup(1);
        assertNull(tower.swapToReduce());
    }
    
    //Pruebas para lidedCups
    
    @Test //LidedCups debe retornar un arreglo con todas las parejas de tazas tapadas presentes
    public void testLidedCupsShouldFindPairsOnTower(){
        tower.pushCup(1);
        tower.pushLid(1);
        tower.pushCup(5);
        tower.pushLid(5);
        tower.pushCup(10);
        tower.pushLid(10);
        assertEquals(3, tower.lidedCups().length);
    }
    
    @Test
    public void testLidedCupsShouldNotCupWithoutLid(){
        tower.pushCup(3);
        tower.pushCup(6);
        tower.pushLid(2);
        assertEquals(0, tower.lidedCups().length);
    }
    
    //Pruebas para stackItems
    
    @Test //StackItems debe de retornar un arreglo con el orden en el que se fueron agregando
          //los items de la torre
    public void testStackItemsShouldReturnCorrectOrder(){
        tower.pushCup(1);
        tower.pushLid(2);
        assertEquals("cup", tower.stackItems()[0][0]);
        assertEquals("lid", tower.stackItems()[1][0]);
    }
    
    @Test
    public void testStackItemsShouldBeEmptyIfTowerIsEmpty(){
        tower.pushCup(2);
        tower.pushLid(2);
        tower.pushCup(1);
        tower.popCup();
        tower.popCup();
        tower.popLid();
        assertEquals(0, tower.stackItems().length);
    }
    //Pruebas para orderTower
    
    @Test //OrderTower organiza los elementos de la torre a partir de su altura.
          //el mas pequeño se pone primero y asi sucesivamente
    public void testOrderTowerShouldSortBasedOnHeight(){
        tower.pushCup(1);
        tower.pushCup(3);
        tower.pushCup(2);
        tower.orderTower();
        assertEquals("1", tower.stackItems()[0][1]);
    }
    
    @Test
    public void testOrderTowerShouldNotWorkWhenTowerIsEmpty(){
        tower.orderTower();
        assertFalse(tower.ok());
    }
    
    //Pruebas para reverseTower
    
    @Test //ReverseTower hace que el ultimo elemento en ingresar a la torre, pase a ser el primero
    public void testReverseTowerShouldReverseTheOrther(){
        tower.pushCup(5);
        tower.pushCup(2);
        tower.pushCup(4);
        tower.reverseTower();
        assertEquals("4", tower.stackItems()[0][1]);
        
    }
    
    @Test
    public void testReverseTowerShouldWorkWhenTowerIsEmpty(){
        tower.reverseTower();
        assertTrue(tower.ok());
    }
}


















