
/**
 * Representa lo que es una tapa en el simulador
 * Como tambien es un rectangulo, hereda algunos metodos y atributos de Rectangle
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lid extends Rectangle{
    private int height;
    private int width;
    private boolean isVisible;
    private String color;
    private int number;    
    
    /**
     * Se crea una tapa con identificador i
     * Su altura siempre es 1 y su anchura es proporcional a i
     */
    public Lid(int i){
        number = i;
        height = 1;
        width = i * 40;
        isVisible = false;
        color = assignColor(i);
        
        changeColor(color);
        changeSize(height * 10, width);
        
    }
    
    /**
     * Hace visible la tapa
     */
    public void makeVisible(){
        isVisible = true;
        super.makeVisible();
    }
    
    /**
     * Hace invisible la tapa
     */
    public void makeInvisible(){
        isVisible = false;
        super.makeInvisible();
    }
    
    /**
     * Retorna la tapa
     */
    public Rectangle getLid(){
        return this;
    }
    
    /**
     * Retorna la altura de la tapa
     */
    public int getHeight(){
        return height;
    }
    
    /**
     * Retorna el ancho de la tapa
     */
    public int getWidth(){
        return width;
    }
    
    /**
     * Retorna el color de la tapa
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Retorna el identificador i de la tapa
     */
    public int getNumber(){
        return number;
    }
    
    /**
     * Retorna si una tapa es visible o no
     */
    public boolean getVisible(){
        return isVisible;
    }
    
    /**
     * Retorna el tipo del objeto
     */
    public String getType(){
        return "lid";
    }

    private String assignColor(int i){
        String[] colors = {"red", "blue", "green", "yellow", "magenta", "cyan", "orange", "pink"};
        return colors[(i - 1) % colors.length];
    }
}