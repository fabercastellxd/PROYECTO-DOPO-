import java.awt.*;

/**
 * A rectangle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes (Modified)
 * @version 1.0  (15 July 2000)()
 */


 
public class Rectangle{

    public static int EDGES = 4;
    
    private int height;
    private int width;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;

    /**
     * 
     * Create a new rectangle at default position with default color.
     */
    public Rectangle(){
        height = 30;
        width = 40;
        if (width < 5){
            width = 5;
        }
        if (width > 500){
            width = 500;
        }
        xPosition = 70;
        yPosition = 15;
        color = "magenta";
        isVisible = false;
    }
    
    //Mueve el rectangulo a una posicion predeterminada
    public void moveToDirection(int x, int y){
    erase();
    xPosition = x;
    yPosition = y;
    draw();
    }
    /**
     * Nuevo metodo llamado perimeter que muestra el perimetro
     */
    public int perimeter(){
        int perimetro = 2*height + 2*width;
        return perimetro;
        
    }
    
    /**
     * Nuevo metodo llamado zoom que aumenta o disminuye el perimetro manteniendo la proporcion
     */
    public void zoom(char z){
        erase();
        if (z == '+'){
            height = height * 2;
            width = width * 2;
        }
        if (z == '-'){
            height = height/2;
            width = width/2;
        }
        draw();
    }
    
    /**
     * Nuevo metodo llamado walk que hace que la figura avace hacia la derecha o izquierda
     */
    public void walk(int times){
        erase();
        if (times < 0){
            xPosition = xPosition - Math.abs(times);
        }
        if (times > 0){
            xPosition = xPosition + Math.abs(times);
        }
        draw();
    }
    
    /**
     * Nuevo metodo llamado crearCuadrado que crea un cuadrado usando el perimetro de este
     */
    public void crearCuadrado(int perimetro){
        int l = perimetro / 4;
        
        erase();
        height = l;
        width = l;
        draw();
    }
    
    
    /**
     * Nuevo metodo llamado invertir que cambia el alrgo del rectangulo por el ancho y viceversa
     */
    public void invertir(){
        erase();
        int originalHeight = height; 
        height = width;
        width = originalHeight;
        draw();
    }

    /**
     * Make this rectangle visible. If it was already visible, do nothing.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     * Make this rectangle invisible. If it was already invisible, do nothing.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }
    
    /**
     * Move the rectangle a few pixels to the right.
     */
    public void moveRight(){
        moveHorizontal(20);
    }

    /**
     * Move the rectangle a few pixels to the left.
     */
    public void moveLeft(){
        moveHorizontal(-20);
    }

    /**
     * Move the rectangle a few pixels up.
     */
    public void moveUp(){
        moveVertical(-20);
    }

    /**
     * Move the rectangle a few pixels down.
     */
    public void moveDown(){
        moveVertical(20);
    }

    /**
     * Move the rectangle horizontally.
     * @param distance the desired distance in pixels
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Move the rectangle vertically.
     * @param distance the desired distance in pixels
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Slowly move the rectangle horizontally.
     * @param distance the desired distance in pixels
     */
    public void slowMoveHorizontal(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Slowly move the rectangle vertically.
     * @param distance the desired distance in pixels
     */
    public void slowMoveVertical(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Change the size to the new size
     * @param newHeight the new height in pixels. newHeight must be >=0.
     * @param newWidht the new width in pixels. newWidth must be >=0.
     */
    public void changeSize(int newHeight, int newWidth) {
        erase();
        height = newHeight;
        width = newWidth;
        draw();
    }
    
    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }
    
    public String getType(){
        return "rectangle";
    }
    
    public int getNumber(){
        return 0;
    }
    
    public int getHeight(){
        return height;
    }

    /*
     * Draw the rectangle with current specifications on screen.
     */

    private void draw() {
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color,
                new java.awt.Rectangle(xPosition, yPosition, 
                                       width, height));
            canvas.wait(10);
        }
    }

    /*
     * Erase the rectangle on screen.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
}

