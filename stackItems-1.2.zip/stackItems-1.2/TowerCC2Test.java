import static org.junit.Assert.*;
import org.junit.Test;
/**
 * Clase con los casos de prueba 
 * 
 * @author Juan Jose Perez Torres
 * @author Maria Angelica Perez Mesa
 * @version (a version number or a date)
 */
public class TowerCC2Test
{
    @Test
    public void accordingPPStackItemsShouldReturnCorrectOrder(){
        Tower tower = new Tower();
        tower.pushCup(5);
        tower.pushLid(5);
        tower.pushLid(2);
        assertEquals("cup", tower.stackItems()[0][0]);
        assertEquals("lid", tower.stackItems()[1][0]);
        assertEquals("lid", tower.stackItems()[2][0]);
    }
    
    @Test
    public void accordingPPLidedCupsShouldReturnAllPairsOnTower(){
        Tower tower = new Tower();
        tower.pushLid(1);
        tower.pushCup(1);
        tower.pushCup(2);
        tower.pushLid(3);
        assertEquals(1, tower.lidedCups().length);
    }
    
    @Test
    public void accordingPPHeightShouldReturnZeroIfTowerIsEmpty(){
        Tower tower = new Tower();
        assertEquals(0, tower.height());
    }
    
    @Test
    public void accordingPPReverseTowerShouldCancellEffectWhenIsApplyTwoTimes(){
        Tower tower = new Tower();
        tower.pushCup(1);
        tower.pushCup(3);
        tower.pushCup(6);
        tower.reverseTower();
        tower.reverseTower();
        assertEquals("cup", tower.stackItems()[0][0]);
        assertEquals("1", tower.stackItems()[0][1]);
        
    }
    
    @Test
    public void accordingPPOrderTowerShouldWorkWithOnlyAItem(){
        Tower tower = new Tower();
        tower.pushCup(10);
        tower.orderTower();
        assertTrue(tower.ok());
    }
    
    @Test
    public void accordingPPCoverShouldFindMultiplePairs(){
        Tower tower = new Tower();
        tower.pushLid(5);
        tower.pushCup(2);
        tower.pushLid(2);
        tower.pushCup(5);
        tower.cover();
        assertEquals(2,tower.lidedCups().length);
    }
    
    @Test
    public void accordingPPSwapShouldNotWorkWithNonExistentObject(){
        Tower tower = new Tower();
        tower.pushLid(6);
        tower.swap(new String[]{"lid","6"}, new String[]{"cup","3"});
    }
    
    @Test
    public void accordingPPSwapToReduceShouldNotWorkWhenTowerIsEmpty(){
        Tower tower = new Tower();
        assertNull(tower.swapToReduce());
    }
}










