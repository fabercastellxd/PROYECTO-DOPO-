import java.util.ArrayList;
import java.util.Collections;
/**
 * Simulador de la torre de tazas
 * la torre contiene tapas y tazas que se van organizando de tal
 * manera para lograr una altura deseada
 * 
 * @author (Juan Jose Perez y Maria Angelica Perez) 
 * @version (15/02/2025)
 */
public class Tower{
    private int width;
    private int maxHeight;
    private boolean isVisible;
    private boolean lastOperationOk;
    
    private Rectangle linea;
    private ArrayList<Rectangle> items;
    
    /**
     * Se crea una torre base con capacidad para 10 elementos
     */
    public Tower(){
        width = 10;
        maxHeight = 10;
        isVisible = false;
        lastOperationOk = true;
        items = new ArrayList<Rectangle> ();
    }
    
    /**
     * Crea una torre con el numero de tazas indicado
     */
    public Tower(int cups){
        this();
        for(int i = 1; i <= cups; i++){
            Cup cup = new Cup(i);
            items.add(cup);
        }
        lastOperationOk = true;
    }
    
    /**
     * Hace visible la torre con sus elementos
     */
    public void makeVisible(){
        isVisible = true;
        /**
         * Se crea un nuevo rectangulo que sera la "linea" que marcara 
         * las dimensiones de la torre
         */
        linea = new Rectangle();
        linea.changeColor("black");
        linea.changeSize(2, 280);
        linea.moveVertical(280);
        linea.moveHorizontal(-65);
        linea.makeVisible();
        
        for (Rectangle item: items) {
            item.makeVisible();
        }
        reposition();
    }
    
    /**
     * Hace invisible la torre y todos sus elementos
     */
    public void makeInvisible() {
        isVisible = false;
        if(linea != null){
            linea.makeInvisible();
        }
        for(Rectangle item: items){
            item.makeInvisible();
        }
    }
    
    /**
     * Retorna un booleano para saber si una taza ya existe
     */
    private boolean existCup(int i){
        for(Rectangle item: items){
            if(item.getType().equals("cup")){
                if(((Cup)item).getNumber() == i){
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Metodo que coloca tapas de acuerdo a su identificador i
     * y de acuerdo a si existe o no
     */
    public void pushCup(int i){
        if(existCup(i) || items.size() >= maxHeight){
            lastOperationOk = false;
            return;
        }
        Cup cup = new Cup(i);
        items.add(cup);
        if (isVisible){
            cup.makeVisible();
            reposition();
        }
        lastOperationOk = true;
    }
    
    /**
     * Reposiciona todos los elementos de la torre
     * de menor a mayor
     */
    private void reposition(){
        int y = 260;
        for(int i = 0; i < items.size(); i++){
            Rectangle item = items.get(i);
            y -= item.getHeight() * 10;
            item.moveToDirection(100, y);
        }
    }
    
    /**
     * Elimina la ultima taza ingeresada en la torre
     */
    public void popCup() {
        for(int i = items.size() - 1; i >= 0; i--){
            if(items.get(i).getType().equals("cup")){
                Rectangle removed = items.remove(i);
                if(isVisible){
                    removed.makeInvisible();
                    reposition();
                }
                lastOperationOk = true;
                return;
            }
        }
        lastOperationOk = false;
    }
    
    /**
     * Remueve una tapa de la torre segun su identificador i
     */
    public void removeCup(int i) {
        for(Rectangle item: items){
            if(item.getType().equals("cup")){
                if(((Cup) item).getNumber() == i){
                    items.remove(item);
                    if (isVisible){
                        item.makeInvisible();
                        reposition();
                    }
                    lastOperationOk = true;
                    return;
                }
            }
        }
        lastOperationOk = false;
    }
    
    /**
     * Retorna un booleano para saber si una tapa ya existe
     */
    private boolean existLid(int i){
        for(Rectangle item: items){
            if(item.getType().equals("lid")){
                if(((Lid) item).getNumber() == i){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Coloca una tapa en la torre de acuerdo a si esta ya existe o no
     */
    public void pushLid(int i) {
        if(existLid(i) || items.size() >= maxHeight){
            lastOperationOk = false;
            return;
        }
        Lid lid = new Lid(i);
        items.add(lid);
        if(isVisible) {
            lid.makeVisible();
            reposition();
        }
        lastOperationOk = true;
    }
    
    /**
     * Elimina la ultima tapa ingresada en la torre
     */
    public void popLid(){
        for(int i = items.size() - 1; i >= 0; i--){
            if(items.get(i).getType().equals("lid")){
                Rectangle removed = items.remove(i);
                if(isVisible){
                    removed.makeInvisible();
                    reposition();
                }
                lastOperationOk = true;
                return;
            }
        }
        lastOperationOk = false;
    }
    
    /**
     * Remueve una tapa en especifico de acuerdo a su identificador i
     */
    public void removeLid(int i) {
        for(Rectangle item: items){
            if(item.getType().equals("lid")){
                if(((Lid)item).getNumber() == i){
                    items.remove(item);
                    if(isVisible){
                        item.makeInvisible();
                        reposition();
                    }
                    lastOperationOk = true;
                    return;
                }
            }
        }
        lastOperationOk = false;
    }
    
    //Nuevos metodos del ciclo 2:
    /**
     * Intercambia la posicion de dos objetos en la torre
     */
    public void swap(String[] o1, String [] o2){
        int idx1 = findIndex(o1[0], Integer.parseInt(o1[1]));
        int idx2 = findIndex(o2[0], Integer.parseInt(o2[1]));
        if (idx1 == -1 || idx2 == -1){
            lastOperationOk = false;
            return;
        }
        Rectangle temp = items.get(idx1);
        items.set(idx1, items.get(idx2));
        items.set(idx2, temp);
        if (isVisible){
            reposition();
        }
        lastOperationOk = true;
        
    }
    
    /**
     * Encuentra en indice de un elemento en la torre de acuerdo al tipo del elemento
     * y a su numero
     */
    private int findIndex(String type, int number){
        for(int i = 0; i < items.size(); i++){
            Rectangle item = items.get(i);
            if (item.getType().equals(type)){
                if(type.equals("cup") && ((Cup) item).getNumber() == number){
                    return i;
                }
                if(type.equals("lid") && ((Lid) item).getNumber() == number){
                    return i;
                }
            }
        }
        return -1;
    }
    
    /**
     * Tapa las tazas que tienen un respectiva tapa en la torre y las
     * marca con un color diferente para identificarla
     */
    public void cover(){
        for(int i = 0; i < items.size(); i++){
            Rectangle item = items.get(i);
            if(item.getType().equals("cup")){
                Cup cup = (Cup) item;
                if (existLid(cup.getNumber())){
                    int lidIndex = findIndex("lid", cup.getNumber());
                    Lid lid = (Lid) items.get(lidIndex);
                    items.remove(lidIndex);
                    items.add(i + 1, lid);
                    lid.changeColor("black");
                    cup.changeColor("magenta");
                }
            }
        }
        if(isVisible){
            reposition();
        }
        lastOperationOk = true;
    }
    
    /**
     * Retorna la altura total de la torre sumando la altura individual
     * de cada elemento dentro de la torre
     */
    public int height(){
        int total = 0;
        for(Rectangle item: items){
            if(item.getType().equals("cup")){
                total += ((Cup) item).getHeight();
            }else{
                total += ((Lid) item).getHeight();
            }
            
        }
        return total;
    }
    
    /**
     * Retorna un arreglo con el numero de las tazas tapadas
     */
    public int[] lidedCups(){
        ArrayList<Integer> result = new ArrayList<Integer>();
        for(Rectangle item : items){
            if (item.getType().equals("cup")){
                Cup cup = (Cup) item;
                if(existLid(cup.getNumber())){
                    result.add(cup.getNumber());
                }
            }
        }
        int[] arr = new int[result.size()];
        for (int i = 0; i < result.size(); i++){
            arr[i] = result.get(i);
        }
        return arr;
    }
    
    /**
     * Retorna un arreglo con todos los elementos en la torre
     * identificados por su tipo de objeto y numero
     */
    public String [][] stackItems(){
        String[][] result = new String[items.size()][2];
        for(int i = 0; i < items.size(); i++){
            Rectangle item = items.get(i);
            if (item.getType().equals("cup")){
                result[i][0] = "cup";
                result[i][1] = String.valueOf(((Cup) item).getNumber());
            }else{
                result[i][0] = "lid";
                result[i][1] = String.valueOf(((Lid) item).getNumber());
            }
        }
        return result;
    }
    
    /**
     * Revisa si un intercambio de elementos puede lograr reducir
     * la altura total de la torre
     */
    public String[][] swapToReduce() {
        int currentHeight = height();
        for(int i = 0; i< items.size(); i++){
            for(int j = i+1; j <items.size();j++){
                Rectangle temp = items.get(i);
                items.set(i, items.get(j));
                items.set(j,temp);
                
                int newHeight = height();
                
                temp= items.get(i);
                items.set(i, items.get(j));
                items.set(j, temp);
                
                if(newHeight < currentHeight){
                    String[][] result = new String[2][2];
                    Rectangle item1 = items.get(i);
                    Rectangle item2 = items.get(j);
                    result [0][0] = item1.getType();
                    result [0][1] = String.valueOf(item1.getNumber());
                    result [1][0] = item2.getType();
                    result[1][1] = String.valueOf (item2.getNumber());   
                    return result;
                }
            }
        }
        return null;
    }
    
    /**
     * Organiza los elemenetos de la tore de menor a mayor altura
     */
    public void orderTower() {
    if (items.isEmpty()) {
        lastOperationOk = false;
        return;
    }
    for (int i = 0; i < items.size() - 1; i++) {
        for (int j = 0; j < items.size() - i - 1; j++) {
            Rectangle item1 = items.get(j);
            Rectangle item2 = items.get(j + 1);
            
            if (item1.getHeight() > item2.getHeight()) {
                items.set(j, item2);
                items.set(j + 1, item1);
            }
        }
    }
    if (isVisible) {
        reposition();
    }
    lastOperationOk = true;
    }
    
    /**
     * Invierte el orden de todos los elementos de la torre
     */
    public void reverseTower(){
        Collections.reverse(items);
        if (isVisible){
            reposition();
        }
        lastOperationOk = true;
    }
    
    /**
     * Cierra el simulador haciendo todo invisible
     */
    public void exit(){
        makeInvisible();
    }
    
    /**
     * Retorna un booleano para saber si la ultima accion realizada
     * es valida o no
     */
    public boolean ok(){
        return lastOperationOk;
    }
}
    
    
